import { Pact } from '@pact-foundation/pact';
import webpackPreprocessor from '@cypress/webpack-preprocessor';
import path from 'path';

console.log('Webpack and Pact setup initialized!');

let pactServer;

export default (on, config) => {
  on('task', {
    createPactProvider() {
      pactServer = new Pact({
        consumer: 'OrderService',
        provider: 'CardPaymentService',
        port: 8282,
        log: 'logs/pact.log',
        dir: 'pacts',
        logLevel: 'info',
      });
      return null;
    },
    startPactProvider() {
      return pactServer.setup();
    },
    addInteraction(interaction) {
      return pactServer.addInteraction(interaction);
    },
    verifyPact() {
      return pactServer.verify();
    },
    finalizePact() {
      return pactServer.finalize();
    },
  });

  const options = {
    webpackOptions: require(path.resolve(__dirname, '../../webpack.config.js')),
  };

  on('file:preprocessor', webpack(options));

  return config;
};
