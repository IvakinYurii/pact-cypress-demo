import { defineConfig } from 'cypress';
import { Pact } from '@pact-foundation/pact';
import path from 'path';

export default defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      let pactProvider: any;  // Declare the pactProvider variable to store Pact instance

      // Register Cypress tasks for managing Pact interactions
      on('task', {
        async createPactProvider(options) {
          // Create a new Pact provider instance
          pactProvider = new Pact({
            consumer: 'OrderService',
            provider: 'CardPaymentService',
            port: 8282,
            log: path.resolve(process.cwd(), 'logs', 'pact.log'),
            dir: path.resolve(process.cwd(), 'pacts'),
            logLevel: 'debug',
            spec: 2,
            ...options,
          });
          return null;
        },
        async startPactProvider() {
          if (pactProvider) {
            // Start the Pact mock server
            await pactProvider.setup();
          }
          return null;
        },
        async addInteraction(interaction) {
          if (pactProvider) {
            // Add interaction to the Pact provider
            await pactProvider.addInteraction(interaction);
          }
          return null;
        },
        async verifyPact() {
          if (pactProvider) {
            // Verify Pact interactions
            await pactProvider.verify();
          }
          return null;
        },
        async finalizePact() {
          if (pactProvider) {
            // Finalize the Pact, write the pact file
            await pactProvider.finalize();
          }
          return null;
        },
      });

      return config;
    },
    supportFile: 'cypress/support/e2e.js',  // This matches your current structure
    specPattern: 'cypress/e2e/**/*.cy.{js,ts}',  // Pattern for finding spec files
  },
});