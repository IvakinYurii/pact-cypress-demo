const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const NodePolyfillPlugin = require('node-polyfill-webpack-plugin');
const webpack = require('webpack');

module.exports = {
  mode: 'development',
  entry: './src/index.js',
  output: {
    filename: 'main.bundle.js',
    path: path.resolve(__dirname, 'dist'),
    clean: true,
  },
  module: {
    rules: [
      {
        test: /\.node$/,
        use: 'node-loader',
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.(png|svg|jpg|jpeg|gif)$/i,
        type: 'asset/resource',
      },
      {
        test: /\.d\.ts$/,
        use: 'ignore-loader',
      },
    ],
  },
  resolve: {
    preferRelative: true,  
    conditionNames: ['browser', 'import', 'module', 'default'],
    fallback: {
      querystring: require.resolve("querystring-es3"), // Use the querystring-es3 polyfill
      buffer: require.resolve('buffer/'),
      path: require.resolve('path-browserify'),
      vm: require.resolve('vm-browserify'),
      crypto: require.resolve('crypto-browserify'),
      stream: require.resolve('stream-browserify'),
      http: require.resolve('stream-http'),
      https: require.resolve('https-browserify'),
      os: require.resolve('os-browserify/browser'),
      tty: require.resolve('tty-browserify'),
      constants: require.resolve('constants-browserify'),
      zlib: require.resolve('browserify-zlib'),
      worker_threads: false, // Disable worker_threads for browser
      fs: false, // Disable fs for browser
      net: false, // Disable net for browser
      tls: false, // Disable tls for browser
      child_process: false, // Disable child_process for browser
      async_hooks: false, // Disable async_hooks for browser
    },
    alias: {
      // Mock 'worker_threads' and other Node.js modules for browser environment
      'worker_threads': path.resolve(__dirname, './cypress/mocks/mock-worker-threads.js'),
      'pnpapi': false,  // Disable pnpapi if not needed
      'module': 'empty-module',
      'path': require.resolve('path-browserify'),  // Use path-browserify for 'path' in browser
      'fs': false,  // 'fs' module is not available in browsers
    },
  },
  externals: {
    'module': 'commonjs module',  // Exclude module from the bundle
    'worker_threads': false, // Exclude worker_threads for browser environment
    'node:path': path.resolve(__dirname, './cypress/mocks/mock-path.js'),  // Mock path as discussed earlier
    'pnpapi': false, 
  }, 
  plugins: [
    new webpack.NormalModuleReplacementPlugin(/^node:/, (resource) => {
      const mod = resource.request.replace(/^node:/, '');
      if (mod === 'path') {
        resource.request = 'path-browserify';
      } else {
        throw new Error(`Unsupported node module: ${mod}`);
      }
    }),
  
  ],
  devServer: {
    static: {
      directory: path.join(__dirname, 'public'),
    },
    port: 8080,
    open: true,
    hot: true,
  },
  devtool: 'inline-source-map',
  ignoreWarnings: [
    {
      module: /@cypress\/webpack-preprocessor/,
      message: /Critical dependency/,
    },
    {
      module: /express|jest-worker/,
      message: /Critical dependency/,
    },
    {
      module: /@swc\/core/,
      message: /Module not found/,
    },
    {
      module: /pino-abstract-transport|pino-pretty/,
      message: /worker_threads/,
    },
  ],
  stats: {
    errorDetails: true,
    warnings: true,
    logging: 'verbose',
  },
};
