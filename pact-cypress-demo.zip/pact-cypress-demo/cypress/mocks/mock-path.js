// mock-path.js
export default {};