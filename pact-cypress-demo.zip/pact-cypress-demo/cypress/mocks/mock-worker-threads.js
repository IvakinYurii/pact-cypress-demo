// mock-worker-threads.js
export default {};