// mock-events.js
export {};