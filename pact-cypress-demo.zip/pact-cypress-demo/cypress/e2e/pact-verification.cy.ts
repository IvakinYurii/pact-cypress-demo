import { Verifier } from '@pact-foundation/pact';
import path from 'path';

describe('Pact Verification for CardPaymentService', () => {
  it('should validate the expectations of OrderService', async () => {
    const opts = {
      provider: 'CardPaymentService',
      providerBaseUrl: 'http://localhost:8080',  // URL of the provider API
      pactBrokerUrl: 'https://informa.pactflow.io',  // Pact broker URL
      pactBrokerToken: 'scBq4w8sDyYU6u25mOQZrg',  // Broker token
      publishVerificationResult: true,  // Publish result back to broker
      providerVersion: '1.0.0',  // Provider version
    };

    let verifier;

    // Only run this section if the environment is Node.js
    if (typeof window === 'undefined') {
      // Dynamically require these modules in Node.js only
      const PinoPretty = require('pino-pretty');
      const PinoAbstractTransport = require('pino-abstract-transport');
      
      verifier = new Verifier(opts);
    }

    if (verifier) {
      await verifier.verifyProvider().then((output: string) => {
        console.log("Pact Verification Complete!");
        console.log(output);
      }).catch((error: any) => {
        console.error("Pact Verification Failed:", error);
        throw new Error(error);
      });
    }
  });
});
